import numpy as np
import pandas as pd
import torch
from pathlib import Path
from torch import nn

from .PMG_DIN import PMG_DIN


class CG_PMG_DIN(PMG_DIN):
    """Cluster-guided PMG-DIN with hard/soft priors and optional dynamic lambda."""

    def __init__(
        self,
        feature_map,
        model_id="CG_PMG_DIN",
        user_cluster_path="./data/MicroLens_1M_x1/user_cluster.parquet",
        num_clusters=32,
        lambda_init=0.5,
        entropy_reg=0.01,
        use_personal_gate=True,
        use_cluster_prior=True,
        fixed_lambda=-1.0,
        drop_text=False,
        drop_image=False,
        drop_attr=False,
        cluster_assignment="hard",
        soft_cluster_tau=1.0,
        dynamic_lambda=False,
        cluster_prior_init_path="",
        **kwargs,
    ):
        self.num_clusters = int(num_clusters)
        self.entropy_reg = float(entropy_reg)
        self.use_personal_gate = bool(use_personal_gate)
        self.use_cluster_prior = bool(use_cluster_prior)
        self.fixed_lambda = float(fixed_lambda)
        self.drop_text = bool(drop_text)
        self.drop_image = bool(drop_image)
        self.drop_attr = bool(drop_attr)
        self.cluster_assignment = str(cluster_assignment).lower()
        self.soft_cluster_tau = max(float(soft_cluster_tau), 1e-6)
        self.dynamic_lambda = bool(dynamic_lambda)

        super(CG_PMG_DIN, self).__init__(feature_map, model_id=model_id, **kwargs)

        lambda_init = min(max(float(lambda_init), 1e-4), 1 - 1e-4)
        lambda_logit = np.log(lambda_init / (1.0 - lambda_init))
        self.lambda_param = nn.Parameter(torch.tensor([lambda_logit], dtype=torch.float32))
        self.cluster_prior_table = nn.Parameter(torch.zeros(self.num_clusters, self.num_modalities))

        if self.dynamic_lambda:
            lambda_in = self.item_info_dim * 2 + self.num_modalities * 2
            self.lambda_mlp = nn.Sequential(nn.Linear(lambda_in, 64), nn.ReLU(), nn.Linear(64, 1))

        self._register_user_clusters(user_cluster_path)
        if cluster_prior_init_path:
            self._init_cluster_prior(cluster_prior_init_path)

        self._last_lambda_entropy = None

        trace_root = Path(kwargs.get("model_root", "./checkpoints/")) / "lambda_traces"
        trace_root.mkdir(parents=True, exist_ok=True)
        self.lambda_trace_path = trace_root / f"{model_id}.csv"
        if not self.lambda_trace_path.exists():
            self.lambda_trace_path.write_text("batch_index,lambda_value\n")

        self.model_to_device()

    @staticmethod
    def _sorted_prefix_cols(columns, prefix):
        cols = [col for col in columns if col.startswith(prefix)]
        return sorted(cols, key=lambda col: int(col.split("_")[-1]))

    def _register_user_clusters(self, user_cluster_path):
        path = Path(user_cluster_path)
        if not path.is_absolute():
            path = Path(__file__).resolve().parent.parent / path

        df = pd.read_parquet(path)
        if "user_id" not in df.columns:
            raise ValueError(f"Missing user_id in {path}")

        prob_cols = self._sorted_prefix_cols(df.columns, "prob_")
        dist_cols = self._sorted_prefix_cols(df.columns, "dist_")

        if "cluster_id" not in df.columns:
            if prob_cols:
                df["cluster_id"] = df[prob_cols].to_numpy(dtype=np.float32).argmax(axis=1).astype(np.int32)
            else:
                raise ValueError(f"Missing cluster_id in {path}")

        max_user_id = int(df["user_id"].max()) + 1
        default_cluster = int(df["cluster_id"].mode().iloc[0]) if len(df) else 0
        cluster_table = np.full(max_user_id, default_cluster, dtype=np.int64)
        for row in df[["user_id", "cluster_id"]].itertuples(index=False):
            user_id = int(row.user_id)
            cluster_id = int(row.cluster_id)
            if 0 <= user_id < max_user_id:
                cluster_table[user_id] = cluster_id

        self.default_cluster_id = default_cluster
        self.register_buffer("user_cluster_table", torch.from_numpy(cluster_table))

        if prob_cols:
            if len(prob_cols) != self.num_clusters:
                raise ValueError(f"prob columns {len(prob_cols)} != num_clusters {self.num_clusters}")
            prob_table = np.tile(
                np.full((1, self.num_clusters), 1.0 / self.num_clusters, dtype=np.float32),
                (max_user_id, 1),
            )
            prob_values = df[prob_cols].to_numpy(dtype=np.float32)
            default_prob = prob_values.mean(axis=0)
            default_prob = default_prob / np.maximum(default_prob.sum(), 1e-8)
            prob_table[:, :] = default_prob[None, :]
            prob_table[df["user_id"].to_numpy(dtype=np.int64)] = prob_values
            self.register_buffer("user_cluster_prob_table", torch.from_numpy(prob_table))
            self.register_buffer("default_cluster_prob", torch.from_numpy(default_prob.astype(np.float32)))

        if dist_cols:
            if len(dist_cols) != self.num_clusters:
                raise ValueError(f"dist columns {len(dist_cols)} != num_clusters {self.num_clusters}")
            dist_values = df[dist_cols].to_numpy(dtype=np.float32)
            default_dist = dist_values.mean(axis=0)
            dist_table = np.tile(default_dist[None, :], (max_user_id, 1))
            dist_table[df["user_id"].to_numpy(dtype=np.int64)] = dist_values
            self.register_buffer("user_cluster_distance_table", torch.from_numpy(dist_table))
            self.register_buffer("default_cluster_distance", torch.from_numpy(default_dist.astype(np.float32)))

    def _init_cluster_prior(self, init_path):
        path = Path(init_path)
        if not path.is_absolute():
            path = Path(__file__).resolve().parent.parent / path

        if path.suffix == ".parquet":
            df = pd.read_parquet(path)
        else:
            df = pd.read_csv(path)

        gate_cols = ["g_text", "g_image", "g_attr", "g_task1"]
        if not set(["cluster_id"] + gate_cols).issubset(df.columns):
            raise ValueError(f"Invalid cluster prior init file: {path}")

        probs = np.full((self.num_clusters, self.num_modalities), 1.0 / self.num_modalities, dtype=np.float32)
        global_gate = df[gate_cols].to_numpy(dtype=np.float32).mean(axis=0)
        global_gate = global_gate / np.maximum(global_gate.sum(), 1e-8)
        probs[:, :] = global_gate[None, :]

        for row in df.itertuples(index=False):
            cluster_id = int(row.cluster_id)
            if 0 <= cluster_id < self.num_clusters:
                gate = np.asarray([row.g_text, row.g_image, row.g_attr, row.g_task1], dtype=np.float32)
                gate = gate / np.maximum(gate.sum(), 1e-8)
                probs[cluster_id] = gate

        logits = np.log(np.clip(probs, 1e-6, 1.0))
        with torch.no_grad():
            self.cluster_prior_table.copy_(torch.from_numpy(logits))

    def _build_modality_embeddings(self, target_ids, item_dict, batch_size):
        modalities = super()._build_modality_embeddings(target_ids, item_dict, batch_size)
        if self.drop_text:
            modalities["text"] = torch.zeros_like(modalities["text"])
        if self.drop_image:
            modalities["image"] = torch.zeros_like(modalities["image"])
        if self.drop_attr:
            modalities["attr"] = torch.zeros_like(modalities["attr"])
        return modalities

    def _lookup_cluster_ids(self, user_ids):
        max_user_id = self.user_cluster_table.size(0) - 1
        clipped = user_ids.clamp(min=0, max=max_user_id)
        cluster_ids = self.user_cluster_table[clipped].long()
        unknown_mask = user_ids > max_user_id
        if unknown_mask.any():
            cluster_ids = torch.where(
                unknown_mask, torch.full_like(cluster_ids, int(self.default_cluster_id)), cluster_ids
            )
        return cluster_ids

    def _default_soft_weights(self, device, dtype):
        prob_table = getattr(self, "user_cluster_prob_table", None)
        default_prob = getattr(self, "default_cluster_prob", None)
        distance_table = getattr(self, "user_cluster_distance_table", None)
        default_distance = getattr(self, "default_cluster_distance", None)

        if prob_table is not None and default_prob is not None:
            return default_prob.to(device=device, dtype=dtype)
        if distance_table is not None and default_distance is not None:
            return torch.softmax(-default_distance.to(device=device, dtype=dtype) / self.soft_cluster_tau, dim=-1)
        return torch.nn.functional.one_hot(
            torch.tensor(int(self.default_cluster_id), device=device), num_classes=self.num_clusters
        ).to(dtype=dtype)

    def _lookup_cluster_weights(self, user_ids):
        if self.cluster_assignment != "soft":
            return None

        max_user_id = self.user_cluster_table.size(0) - 1
        clipped = user_ids.clamp(min=0, max=max_user_id)
        unknown_mask = user_ids > max_user_id

        prob_table = getattr(self, "user_cluster_prob_table", None)
        distance_table = getattr(self, "user_cluster_distance_table", None)

        if prob_table is not None:
            weights = prob_table[clipped].to(dtype=torch.float32)
            weights = weights / weights.sum(dim=-1, keepdim=True).clamp_min(1e-8)
        elif distance_table is not None:
            distance = distance_table[clipped].to(dtype=torch.float32)
            weights = torch.softmax(-distance / self.soft_cluster_tau, dim=-1)
        else:
            cluster_ids = self._lookup_cluster_ids(user_ids)
            weights = torch.nn.functional.one_hot(cluster_ids, num_classes=self.num_clusters).float()

        if unknown_mask.any():
            default_weights = self._default_soft_weights(weights.device, weights.dtype).view(1, -1)
            weights = torch.where(unknown_mask.view(-1, 1), default_weights, weights)
        return weights

    def _combine_gates(self, personal_gate, user_interest, target_emb, user_ids):
        batch_size = personal_gate.size(0)
        cluster_gate = None
        cluster_ids = None
        cluster_weights = None
        lambda_value = torch.ones((batch_size, 1), dtype=personal_gate.dtype, device=personal_gate.device)

        if self.use_cluster_prior:
            cluster_ids = self._lookup_cluster_ids(user_ids)
            cluster_prior = torch.softmax(self.cluster_prior_table, dim=-1)
            cluster_weights = self._lookup_cluster_weights(user_ids)
            if cluster_weights is not None:
                cluster_weights = cluster_weights.to(device=personal_gate.device, dtype=personal_gate.dtype)
                cluster_gate = torch.matmul(cluster_weights, cluster_prior)
            else:
                cluster_gate = cluster_prior[cluster_ids]

        if not self.use_personal_gate:
            if cluster_gate is not None:
                gate = cluster_gate
                lambda_value = torch.zeros((batch_size, 1), dtype=personal_gate.dtype, device=personal_gate.device)
            else:
                gate = personal_gate
        elif not self.use_cluster_prior or cluster_gate is None:
            gate = personal_gate
        else:
            if self.fixed_lambda >= 0:
                lambda_scalar = min(max(self.fixed_lambda, 0.0), 1.0)
                lambda_value = torch.full(
                    (batch_size, 1), lambda_scalar, dtype=personal_gate.dtype, device=personal_gate.device
                )
            elif self.dynamic_lambda:
                lambda_input = torch.cat([user_interest, target_emb, personal_gate, cluster_gate], dim=-1)
                lambda_value = torch.sigmoid(self.lambda_mlp(lambda_input))
            else:
                lambda_value = torch.sigmoid(self.lambda_param).view(1, 1).expand(batch_size, 1)
            gate = lambda_value * personal_gate + (1.0 - lambda_value) * cluster_gate

        if self.use_personal_gate and self.use_cluster_prior and cluster_gate is not None and self.fixed_lambda < 0:
            entropy = -(
                lambda_value * torch.log(lambda_value.clamp_min(1e-8))
                + (1.0 - lambda_value) * torch.log((1.0 - lambda_value).clamp_min(1e-8))
            )
            self._last_lambda_entropy = entropy.mean()
        else:
            self._last_lambda_entropy = None

        return gate, {
            "cluster_gate": cluster_gate,
            "cluster_ids": cluster_ids,
            "cluster_weights": cluster_weights,
            "lambda_value": lambda_value,
        }

    def train_step(self, batch_data):
        return_dict = self.forward(batch_data)
        y_true = self.get_labels(batch_data)
        loss = self.compute_loss(return_dict, y_true)
        loss = loss + self._auxiliary_loss(return_dict, y_true)
        if self.entropy_reg > 0 and self._last_lambda_entropy is not None:
            loss = loss - self.entropy_reg * self._last_lambda_entropy

        debug_cache = self.get_debug_cache()
        lambda_tensor = debug_cache.get("lambda_value")
        if lambda_tensor is not None and self._batch_index % 100 == 0:
            lambda_value = float(lambda_tensor.mean().detach().cpu().item())
            with self.lambda_trace_path.open("a") as fout:
                fout.write(f"{self._batch_index},{lambda_value}\n")

        loss = loss / self.accumulation_steps
        loss.backward()
        if (self._batch_index + 1) % self.accumulation_steps == 0:
            nn.utils.clip_grad_norm_(self.parameters(), self._max_gradient_norm)
            self.optimizer.step()
            self.optimizer.zero_grad()
        return loss
