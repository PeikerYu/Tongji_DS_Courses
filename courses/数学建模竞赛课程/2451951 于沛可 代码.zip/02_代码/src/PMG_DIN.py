import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from pathlib import Path
from torch import nn

from fuxictr.pytorch.layers import CrossNetV2, DIN_Attention, Dice, FeatureEmbedding, MLP_Block
from fuxictr.pytorch.models import BaseModel
from fuxictr.utils import not_in_whitelist


class PMG_DIN(BaseModel):
    """Personalized Multimodal Gated DIN with optional DCNv2 refinement."""

    def __init__(
        self,
        feature_map,
        model_id="PMG_DIN",
        gpu=-1,
        dnn_hidden_units=(512, 128, 64),
        dnn_activations="ReLU",
        attention_hidden_units=(64,),
        attention_hidden_activations="Dice",
        attention_output_activation=None,
        attention_dropout=0,
        learning_rate=1e-3,
        embedding_dim=10,
        net_dropout=0,
        batch_norm=False,
        din_use_softmax=False,
        accumulation_steps=1,
        embedding_regularizer=None,
        net_regularizer=None,
        item_feature_path="./data/item_feature.parquet",
        modal_dim=64,
        use_dcn=False,
        cross_layers=3,
        dcn_mode="cross_only",
        aux_modal_beta=0.0,
        use_late_fusion=False,
        modality_dropout_p=0.0,
        **kwargs,
    ):
        super(PMG_DIN, self).__init__(
            feature_map,
            model_id=model_id,
            gpu=gpu,
            embedding_regularizer=embedding_regularizer,
            net_regularizer=net_regularizer,
            **kwargs,
        )
        if isinstance(dnn_activations, str) and dnn_activations.lower() == "dice":
            dnn_activations = [Dice(units) for units in dnn_hidden_units]
        if isinstance(attention_hidden_units, int):
            attention_hidden_units = [attention_hidden_units]
        if isinstance(dnn_hidden_units, int):
            dnn_hidden_units = [dnn_hidden_units]
        self.feature_map = feature_map
        self.embedding_dim = embedding_dim
        self.modal_dim = modal_dim
        self.modal_names = ("text", "image", "attr", "task1")
        self.num_modalities = len(self.modal_names)
        self.use_dcn = bool(use_dcn)
        self.cross_layers = int(cross_layers)
        self.dcn_mode = str(dcn_mode).lower()
        self.aux_modal_beta = float(aux_modal_beta)
        self.use_late_fusion = bool(use_late_fusion)
        self.modality_dropout_p = float(modality_dropout_p)
        self.item_info_dim = 0
        for feat, spec in self.feature_map.features.items():
            if spec.get("source") == "item":
                self.item_info_dim += spec.get("embedding_dim", embedding_dim)
        self.accumulation_steps = accumulation_steps
        self.embedding_layer = FeatureEmbedding(feature_map, embedding_dim)
        self.attention_layers = DIN_Attention(
            self.item_info_dim,
            attention_units=attention_hidden_units,
            hidden_activations=attention_hidden_activations,
            output_activation=attention_output_activation,
            dropout_rate=attention_dropout,
            use_softmax=din_use_softmax,
        )
        self._register_item_side_tables(item_feature_path)

        self.text_proj = nn.Linear(self.text_dim, modal_dim)
        self.image_proj = nn.Linear(self.image_dim, modal_dim)
        self.attr_proj = MLP_Block(
            input_dim=3,
            output_dim=modal_dim,
            hidden_units=[32],
            hidden_activations="ReLU",
            output_activation=None,
            batch_norm=False,
        )
        self.task1_proj = nn.Linear(128, modal_dim)

        gate_in = self.item_info_dim + modal_dim * self.num_modalities
        self.gate_mlp = MLP_Block(
            input_dim=gate_in,
            output_dim=self.num_modalities,
            hidden_units=[128, 64],
            hidden_activations="ReLU",
            output_activation=None,
            batch_norm=False,
        )
        self.modal_logit_heads = None
        self.late_pi = None
        self.late_alpha = None
        if self.aux_modal_beta > 0 or self.use_late_fusion:
            self.modal_logit_heads = nn.ModuleList(
                [nn.Linear(modal_dim, 1) for _ in self.modal_names]
            )
        if self.use_late_fusion:
            self.late_pi = nn.Parameter(torch.zeros(self.num_modalities, dtype=torch.float32))
            self.late_alpha = nn.Parameter(torch.zeros(1, dtype=torch.float32))

        self.final_input_dim = feature_map.sum_emb_out_dim() + self.item_info_dim + modal_dim
        if self.use_dcn:
            self.cross_net = CrossNetV2(self.final_input_dim, self.cross_layers)
        dnn_input_dim = self.final_input_dim
        if self.use_dcn and self.dcn_mode == "parallel":
            dnn_input_dim = self.final_input_dim * 2
        dnn_output_activation = None if self.use_late_fusion else self.output_activation
        self.dnn = MLP_Block(
            input_dim=dnn_input_dim,
            output_dim=1,
            hidden_units=dnn_hidden_units,
            hidden_activations=dnn_activations,
            output_activation=dnn_output_activation,
            dropout_rates=net_dropout,
            batch_norm=batch_norm,
        )
        self._debug_cache = {}
        self.compile(kwargs["optimizer"], kwargs["loss"], learning_rate)
        self.reset_parameters()
        self.model_to_device()

    def _register_item_side_tables(self, item_feature_path):
        path = Path(item_feature_path)
        if not path.is_absolute():
            path = Path(__file__).resolve().parent.parent / path
        df = pd.read_parquet(path)
        max_id = int(max(df["item_id"].max(), 91717)) + 1
        text_dim = len(np.asarray(df.iloc[0]["txt_emb_BERT"]))
        image_dim = len(np.asarray(df.iloc[0]["img_emb_CLIPRN50"]))
        self.text_dim = text_dim
        self.image_dim = image_dim

        text_table = np.zeros((max_id, text_dim), dtype=np.float32)
        image_table = np.zeros((max_id, image_dim), dtype=np.float32)
        likes_table = np.zeros(max_id, dtype=np.float32)
        views_table = np.zeros(max_id, dtype=np.float32)
        tag_count_table = np.zeros(max_id, dtype=np.float32)

        for row in df.itertuples(index=False):
            iid = int(row.item_id)
            if iid >= max_id:
                continue
            text_table[iid] = np.asarray(row.txt_emb_BERT, dtype=np.float32)
            image_table[iid] = np.asarray(row.img_emb_CLIPRN50, dtype=np.float32)
            likes_table[iid] = float(row.likes_level)
            views_table[iid] = float(row.views_level)
            tags = np.asarray(row.item_tags, dtype=np.float32)
            tag_count_table[iid] = float(np.count_nonzero(tags))

        self.register_buffer("text_table", torch.from_numpy(text_table))
        self.register_buffer("image_table", torch.from_numpy(image_table))
        self.register_buffer("likes_table", torch.from_numpy(likes_table))
        self.register_buffer("views_table", torch.from_numpy(views_table))
        self.register_buffer("tag_count_table", torch.from_numpy(tag_count_table))

    def _target_item_ids(self, item_dict, batch_size):
        item_ids = item_dict["item_id"]
        seq_items = item_ids.view(batch_size, -1)
        return seq_items[:, -1].long()

    def _build_modality_embeddings(self, target_ids, item_dict, batch_size):
        e_text = self.text_proj(self.text_table[target_ids])
        e_image = self.image_proj(self.image_table[target_ids])
        likes = self.likes_table[target_ids].unsqueeze(-1) / 10.0
        views = self.views_table[target_ids].unsqueeze(-1) / 10.0
        tags = self.tag_count_table[target_ids].unsqueeze(-1) / 5.0
        e_attr = self.attr_proj(torch.cat([likes, views, tags], dim=-1))
        raw_emb = item_dict["item_emb_d128"].float()
        e_task1 = self.task1_proj(raw_emb.view(batch_size, -1, 128)[:, -1, :])
        modalities = {
            "text": e_text,
            "image": e_image,
            "attr": e_attr,
            "task1": e_task1,
        }
        if self.training and self.modality_dropout_p > 0:
            modalities = self._apply_modality_dropout(modalities)
        return modalities

    def _apply_modality_dropout(self, modalities):
        batch_size = next(iter(modalities.values())).size(0)
        device = next(iter(modalities.values())).device
        drop_mask = torch.rand(batch_size, self.num_modalities, device=device) < self.modality_dropout_p
        all_dropped = drop_mask.all(dim=1)
        if all_dropped.any():
            keep_indices = torch.randint(self.num_modalities, (int(all_dropped.sum().item()),), device=device)
            drop_mask[all_dropped] = True
            drop_mask[all_dropped, keep_indices] = False
        for idx, name in enumerate(self.modal_names):
            modalities[name] = modalities[name].masked_fill(drop_mask[:, idx].unsqueeze(-1), 0.0)
        return modalities

    def _compute_modal_logits(self, modalities):
        if self.modal_logit_heads is None:
            return None
        logits = []
        for idx, name in enumerate(self.modal_names):
            logits.append(self.modal_logit_heads[idx](modalities[name]))
        return torch.cat(logits, dim=-1)

    def _compute_personal_gate(self, user_interest, modalities):
        gate_input = torch.cat(
            [user_interest] + [modalities[name] for name in self.modal_names],
            dim=-1,
        )
        gate_logits = self.gate_mlp(gate_input)
        return torch.softmax(gate_logits, dim=-1)

    def _combine_gates(self, personal_gate, user_interest, target_emb, user_ids):
        lambda_value = torch.ones(
            (personal_gate.size(0), 1),
            dtype=personal_gate.dtype,
            device=personal_gate.device,
        )
        return personal_gate, {
            "cluster_gate": None,
            "cluster_ids": None,
            "cluster_weights": None,
            "lambda_value": lambda_value,
        }

    def _fuse_modalities(self, modalities, gate):
        modal_stack = torch.stack([modalities[name] for name in self.modal_names], dim=1)
        return (modal_stack * gate.unsqueeze(-1)).sum(dim=1)

    def _set_debug_cache(self, **kwargs):
        cache = {}
        for key, value in kwargs.items():
            if value is None:
                continue
            if torch.is_tensor(value):
                cache[key] = value.detach()
            else:
                cache[key] = value
        self._debug_cache = cache

    def get_debug_cache(self):
        return self._debug_cache

    def _late_fusion_logit(self, modal_logits):
        if modal_logits is None or not self.use_late_fusion or self.late_pi is None:
            return None, None
        late_weights = torch.softmax(self.late_pi, dim=0)
        late_logit = (modal_logits * late_weights.view(1, -1)).sum(dim=-1, keepdim=True)
        return late_logit, late_weights

    def _auxiliary_loss(self, return_dict, y_true):
        modal_logits = return_dict.get("modal_aux_logits")
        if modal_logits is None or self.aux_modal_beta <= 0:
            return y_true.new_zeros(())
        y_expand = y_true.expand(-1, modal_logits.size(1))
        aux_loss = F.binary_cross_entropy_with_logits(modal_logits, y_expand)
        return aux_loss * self.aux_modal_beta

    def _modal_features(self, user_interest, target_emb, item_dict, batch_size, user_ids=None):
        target_ids = self._target_item_ids(item_dict, batch_size)
        modalities = self._build_modality_embeddings(target_ids, item_dict, batch_size)
        modal_logits = self._compute_modal_logits(modalities)
        personal_gate = self._compute_personal_gate(user_interest, modalities)
        gate, gate_aux = self._combine_gates(personal_gate, user_interest, target_emb, user_ids)
        gate = gate / gate.sum(dim=-1, keepdim=True).clamp_min(1e-8)
        e_mm = self._fuse_modalities(modalities, gate)
        self._set_debug_cache(
            user_id=user_ids,
            target_item_id=target_ids,
            personal_gate=personal_gate,
            fused_gate=gate,
            cluster_gate=gate_aux.get("cluster_gate"),
            cluster_ids=gate_aux.get("cluster_ids"),
            cluster_weights=gate_aux.get("cluster_weights"),
            lambda_value=gate_aux.get("lambda_value"),
            modal_aux_logits=modal_logits,
        )
        return e_mm, gate, modal_logits

    def _apply_final_interactions(self, feature_emb):
        if not self.use_dcn:
            return feature_emb
        cross_out = self.cross_net(feature_emb)
        if self.dcn_mode == "parallel":
            return torch.cat([feature_emb, cross_out], dim=-1)
        return cross_out

    def forward(self, inputs):
        raw_batch_dict = inputs[0]
        batch_dict, item_dict, mask = self.get_inputs(inputs)
        emb_list = []
        if batch_dict:
            feature_emb = self.embedding_layer(batch_dict, flatten_emb=True)
            emb_list.append(feature_emb)
        item_feat_emb = self.embedding_layer(item_dict, flatten_emb=True)
        batch_size = mask.shape[0]
        item_feat_emb = item_feat_emb.view(batch_size, -1, self.item_info_dim)
        target_emb = item_feat_emb[:, -1, :]
        sequence_emb = item_feat_emb[:, 0:-1, :]
        pooling_emb = self.attention_layers(target_emb, sequence_emb, mask)
        user_ids = None
        if "user_id" in raw_batch_dict:
            user_ids = raw_batch_dict["user_id"].to(self.device).long().view(-1)
        e_mm, _gate, modal_logits = self._modal_features(
            pooling_emb,
            target_emb,
            item_dict,
            batch_size,
            user_ids=user_ids,
        )
        emb_list += [target_emb, pooling_emb, e_mm]
        feature_emb = torch.cat(emb_list, dim=-1)
        feature_emb = self._apply_final_interactions(feature_emb)
        early_pred = self.dnn(feature_emb)
        late_logit, late_weights = self._late_fusion_logit(modal_logits)
        if late_logit is None:
            y_pred = early_pred
        else:
            early_logit = early_pred
            final_logit = early_logit + self.late_alpha * late_logit
            y_pred = torch.sigmoid(final_logit)
            self._set_debug_cache(
                **self.get_debug_cache(),
                late_fusion_weights=late_weights,
                late_fusion_logit=late_logit,
                late_alpha=self.late_alpha,
            )
        return {
            "y_pred": y_pred,
            "modal_aux_logits": modal_logits,
            "late_fusion_logit": late_logit,
        }

    def get_inputs(self, inputs, feature_source=None):
        batch_dict, item_dict, mask = inputs
        X_dict = dict()
        for feature, value in batch_dict.items():
            if feature in self.feature_map.labels:
                continue
            feature_spec = self.feature_map.features[feature]
            if feature_spec["type"] == "meta":
                continue
            if feature_source and not_in_whitelist(feature_spec["source"], feature_source):
                continue
            X_dict[feature] = value.to(self.device)
        item_dict = dict(item_dict)
        for item, value in item_dict.items():
            item_dict[item] = value.to(self.device)
        return X_dict, item_dict, mask.to(self.device)

    def get_labels(self, inputs):
        labels = self.feature_map.labels
        batch_dict = inputs[0]
        y = batch_dict[labels[0]].to(self.device)
        return y.float().view(-1, 1)

    def get_group_id(self, inputs):
        return inputs[0][self.feature_map.group_id]

    def train_step(self, batch_data):
        return_dict = self.forward(batch_data)
        y_true = self.get_labels(batch_data)
        loss = self.compute_loss(return_dict, y_true)
        loss = loss + self._auxiliary_loss(return_dict, y_true)
        loss = loss / self.accumulation_steps
        loss.backward()
        if (self._batch_index + 1) % self.accumulation_steps == 0:
            nn.utils.clip_grad_norm_(self.parameters(), self._max_gradient_norm)
            self.optimizer.step()
            self.optimizer.zero_grad()
        return loss
