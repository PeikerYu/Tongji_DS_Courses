# ACMF-PMG-DIN 多模态点击率预测

基于 FuxiCTR 框架，在 WWW2025 MM-CTR Challenge Task2 上实现的多模态 CTR 模型。

## 环境

```bash
conda create -n mmctr python=3.9
conda activate mmctr
pip install -r requirements.txt
```

主要依赖：torch、fuxictr==2.3.7、pyarrow、pandas。

## 数据准备

从赛题官网下载 MicroLens 数据，解压到 `data/` 目录，需包含：

```
data/MicroLens_1M_x1/train.parquet
data/MicroLens_1M_x1/valid.parquet
data/MicroLens_1M_x1/test.parquet
data/MicroLens_1M_x1/item_info_cmte_no_transformer.parquet
data/item_feature.parquet
```

## 训练

最终模型对应实验 ID：`T2_ACMF_MDS_ELF`

```bash
bash scripts/run_task2_round.sh T2_ACMF_MDS_ELF 0 1
```

参数说明：实验 ID、GPU 编号、是否在训练结束后跑验证集（0/1）。训练日志里会打印验证集指标。

其他对比实验（基线、消融）可在 `config/TASK2_round_no_transformer/model_config.yaml` 里找到对应 ID，例如 `T2_BASE_PMG_DIN`、`T2_SOFT_3`、`T2_ACMF_MDS` 等。

## 测试集预测与提交

```bash
python submit_task2.py \
  --config config/TASK2_round_no_transformer \
  --expid T2_ACMF_MDS_ELF \
  --gpu 0 \
  --task-col Task2 \
  --out-name T2_ACMF_MDS_ELF_task2
```

输出文件：`submission/T2_ACMF_MDS_ELF_task2.zip`，上传到 Codabench 即可。

## 代码结构

```
src/
  PMG_DIN.py       # DIN + 个性化门控 + MDS/ELF
  CG_PMG_DIN.py    # 先验平滑（cluster prior）
  mmctr_dataloader.py
config/            # 实验配置
scripts/           # 训练/评估脚本
```

## 主要结果

| 模型 | 验证集 AUC | 验证集 Logloss |
|------|-----------|----------------|
| PMG-DIN | 0.981215 | 0.184657 |
| PS-PMG-DIN | 0.981955 | 0.155866 |
| ACMF-PMG-DIN | 0.982644 | 0.154708 |

Codabench 测试集 AUC：0.9853（Task2 排行榜第 13 名）。

详细实验与分析见 `01_报告/main.pdf`。
