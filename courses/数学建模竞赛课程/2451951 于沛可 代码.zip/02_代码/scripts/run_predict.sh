#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
CFG="${1:?config dir required}"
EXPID="${2:?expid required}"
GPU="${3:-0}"
LOG="logs/predict_${EXPID}_$(date +%Y%m%d_%H%M%S).log"
mkdir -p logs
conda run --no-capture-output -n mmctr_fuxictr python prediction.py \
  --config "$CFG" \
  --expid "$EXPID" \
  --gpu "$GPU" 2>&1 | tee "$LOG"
echo "Prediction log: $LOG"
