#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

EXPID="${1:?expid required}"
GPU="${2:-0}"
RUN_VALID="${3:-0}"
CFG="config/TASK2_round_no_transformer"
mkdir -p logs

LOG="logs/${EXPID}_$(date +%Y%m%d_%H%M%S).log"
conda run --no-capture-output -n mmctr_fuxictr python run_expid.py \
  --config "$CFG" \
  --expid "$EXPID" \
  --gpu "$GPU" 2>&1 | tee "$LOG"
echo "Task2 round log: $LOG"

if [[ "$RUN_VALID" == "1" ]]; then
  bash scripts/run_valid_eval.sh "$CFG" "$EXPID" "$GPU" "$EXPID"
fi
