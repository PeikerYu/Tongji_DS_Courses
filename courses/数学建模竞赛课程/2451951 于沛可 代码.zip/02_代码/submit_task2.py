#!/usr/bin/env python3
# 生成 Task2 测试集预测并打包为 submission zip

import argparse
import logging
import os
import shutil

import numpy as np
import pandas as pd

import fuxictr_version  # noqa: F401
from fuxictr.features import FeatureMap
from fuxictr.preprocess import FeatureProcessor, build_dataset
from fuxictr.pytorch.dataloaders import RankDataLoader
from fuxictr.pytorch.torch_utils import seed_everything
from fuxictr.utils import load_config, print_to_json, set_logger

import src as model_zoo
from src.mmctr_dataloader import MMCTRDataLoader


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("--expid", type=str, required=True)
    parser.add_argument("--gpu", type=int, default=-1)
    parser.add_argument("--task-col", type=str, default="Task2", choices=["Task1", "Task2", "Task1&2"])
    parser.add_argument("--out-name", type=str, default=None)
    args = vars(parser.parse_args())

    experiment_id = args["expid"]
    params = load_config(args["config"], experiment_id)
    params["gpu"] = args["gpu"]
    set_logger(params)
    logging.info("Params: " + print_to_json(params))
    seed_everything(seed=params["seed"])

    data_dir = os.path.join(params["data_root"], params["dataset_id"])
    feature_map_json = os.path.join(data_dir, "feature_map.json")
    feature_encoder = FeatureProcessor(**params)
    params["train_data"], params["valid_data"], params["test_data"] = build_dataset(feature_encoder, **params)
    feature_map = FeatureMap(params["dataset_id"], data_dir)
    feature_map.load(feature_map_json, params)

    model_class = getattr(model_zoo, params["model"])
    model = model_class(feature_map, **params)
    model.count_parameters()

    params["data_loader"] = MMCTRDataLoader
    RankDataLoader(feature_map, stage="train", **params).make_iterator()
    model.load_weights(model.checkpoint)

    test_gen = RankDataLoader(feature_map, stage="test", **params).make_iterator()
    test_pred = model.predict(test_gen)

    test_df = pd.read_parquet(params["test_data"])
    ids = test_df["ID"].to_numpy() if "ID" in test_df.columns else np.arange(len(test_df))
    if len(ids) != len(test_pred):
        raise ValueError(f"预测行数 {len(test_pred)} 与测试集 {len(ids)} 不一致")

    task_col = args["task_col"]
    ans = pd.DataFrame({"ID": ids, task_col: test_pred})

    os.makedirs("submission", exist_ok=True)
    ans.to_csv("submission/prediction.csv", index=False)

    out_stem = args["out_name"] or experiment_id
    shutil.make_archive(f"submission/{out_stem}", "zip", "submission/", "prediction.csv")
    logging.info(f"已写入 submission/{out_stem}.zip")


if __name__ == "__main__":
    main()
